Das Makefile wurde großzügig vom David Rieser bereitgestellt. 

Nach gestrigen Vergleich des Codes mit dem vom David Rieser wurde festgestellt, 
dass die Programme recht ähnlich sind. Jedoch wurde das Projekt komplett unabhängig 
geschrieben, der David Rieser kann dies bestätigen. 

Denke da wir relativ viel gemeinsam Programmiert haben und der David mir generell viel 
erklärt hat sich mein Programmierstil langsam an seinen angepasst XD.